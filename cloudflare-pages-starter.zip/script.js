document.addEventListener('DOMContentLoaded', () => {
  console.log('Cloudflare Pages starter loaded.');
});